/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
'use strict';

const { Gateway, Wallets } = require('fabric-network');
const path = require('path');
const fs = require('fs');

async function main(requestBody) {
    try {
        // Load the network configuration
        const ccpPath = path.resolve(
            __dirname,
            '..',
            '..',
            'test-network',
            'organizations',
            'peerOrganizations',
            'org1.example.com',
            'connection-org1.json'
        );
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        // Create a wallet for managing identities
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check identity
        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Connect to gateway
        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });

        // Get network and contract
        const network = await gateway.getNetwork('mychannel');
        const contract = network.getContract('fabcar');

        // First, get the current property data to preserve existing fields
        const currentDataResult = await contract.evaluateTransaction('readProperty', requestBody.key);
        const currentProperty = JSON.parse(currentDataResult.toString());
        
        // Merge existing data with new updates (updateFields override existing)
        const updatedProperty = { ...currentProperty, ...requestBody.updateFields };
        
        // Use the existing createProperty function to save the merged data
        // This effectively updates the property while preserving unchanged fields
        const result = await contract.submitTransaction(
            'createProperty', 
            requestBody.key,
            updatedProperty.address,
            updatedProperty.city,
            updatedProperty.size,
            updatedProperty.owner,
            updatedProperty.type
        );
        
        console.log(`UPDATE PROPERTY Transaction has been submitted, result is: ${result.toString()}`);

        // Disconnect from the gateway
        await gateway.disconnect();

        // Return the updated property data
        return JSON.stringify(updatedProperty);

    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        throw error;
    }
}

module.exports = {
    main
};