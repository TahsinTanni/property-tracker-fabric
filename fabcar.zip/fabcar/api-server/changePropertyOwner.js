/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const { Gateway, Wallets } = require('fabric-network');
const path = require('path');
const fs = require('fs');

async function main(params) {
    try {
        // load the network configuration
        const ccpPath = path.resolve(
            __dirname,
            '..',
            '..',
            'test-network',
            'organizations',
            'peerOrganizations',
            'org1.example.com',
            'connection-org1.json'
        );
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        // Create a wallet for managing identities
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check identity
        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Connect to gateway
        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });

        // Get network and contract
        const network = await gateway.getNetwork('mychannel');
        const contract = network.getContract('fabcar'); // chaincode name updated

        // For updating only owner
        const key = params.key;
        const newOwner = params.ownerName;

        // Submit the transaction to update owner only
        await contract.submitTransaction('updatePropertyOwner', key, newOwner);
        console.log('Owner has been updated');


        // Disconnect
        await gateway.disconnect();

    } catch (error) {
        console.error(`Failed to create transaction: ${error}`);
        process.exit(1);
    }
}

module.exports = { main };
