/*
 * Module dependencies
 */
const express = require('express');
const cors = require('cors');
const queryProperty = require('./queryProperty');
const createProperty = require('./createProperty');
const updateTracker = require('./updateProperty');  



const bodyParser = require('body-parser');

const app = express();

// To control CORS
app.use(cors());
app.options('*', cors()); 

// To parse encoded data
app.use(bodyParser.json());       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({  // to support URL-encoded bodies
  extended: true
})); 



// Get all properties or search by unique ID / city
app.get('/get-property', async function (req, res) {
    try {
        const result = await queryProperty.main(req.query);
        const parsedData = JSON.parse(result);

        // 🔹 If searching by key (unique ID)
        if (req.query.key) {
            if (!parsedData || Object.keys(parsedData).length === 0) {
                return res.status(404).send({ error: 'Property not found' });
            }

            // Wrap the single object in the expected array format
            const propertyList = [
                {
                    Key: req.query.key,
                    Record: parsedData
                }
            ];

            return res.send(propertyList);
        }

        // 🔹 If searching by city
        if (req.query.city) {
            if (!parsedData || parsedData.length === 0) {
                return res.status(404).send({ error: 'No properties found in this city' });
            }
            // Already an array of results → send directly
            return res.send(parsedData);
        }

        // 🔹 Otherwise → return all properties
        res.send(parsedData);

    } catch (err) {
        console.error({ err });
        res.status(500).send({ error: 'FAILED TO GET DATA!' });
    }
});


// Create a new property
app.post('/create', function (req, res) {
    createProperty.main(req.body)
    .then(result => {
        res.send({ message: 'Property created successfully' });
    })
    .catch(err => {
        console.error({ err });
        res.send('FAILED TO CREATE PROPERTY!');
    });
});



// Update property Details
app.post('/partial-update', async (req, res) => {
    try {
        const requestBody = {
            key: req.body.key,
            updateFields: {
                address: req.body.address || undefined,
                city: req.body.city || undefined,
                size: req.body.size || undefined,
                owner: req.body.owner || undefined,
                type: req.body.type || undefined
            }
        };

        // Remove empty fields
        Object.keys(requestBody.updateFields).forEach(
            key => requestBody.updateFields[key] === undefined && delete requestBody.updateFields[key]
        );

        const result = await updateTracker.main(requestBody);
        res.json({ message: 'Property updated successfully', data: JSON.parse(result) });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});





app.listen(3000, () => console.log('Property Tracker Server running at port 3000'));